function h= sum_heads(r)
  h = sum(r(r == true));
end